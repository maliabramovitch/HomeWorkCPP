//
// Created by Mali Abramovitch on 02/12/2022.
//

#include "GameSquare.h"

GameSquare::GameSquare(int xVal, int yVal) : x(xVal), y(yVal) {}