//
// Created by Mali Abramovitch on 07/01/2023.
//

#ifndef INC_14_MIMIVIRUS_H
#define INC_14_MIMIVIRUS_H


#include "Virus.h"

class Mimivirus : public Virus{
public:
    Mimivirus(std::string name1, int *per1, int size1, int *familySize1);
};


#endif //INC_14_MIMIVIRUS_H
